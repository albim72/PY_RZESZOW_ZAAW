import tensorflow as tf
print(f"Wersja TF: {tf.__version__}")

mnist = tf.keras.datasets.mnist